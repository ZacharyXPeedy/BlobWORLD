chrome.action.onClicked.addListener(() => {
  const width = 800;
  const height = 600;

  chrome.system.display.getInfo((displays) => {
    const primaryDisplay = displays.find(display => display.isPrimary) || displays[0];
    const bounds = primaryDisplay.workArea;

    const left = Math.round(bounds.left + (bounds.width - width) / 2);
    const top = Math.round(bounds.top + (bounds.height - height) / 2);

    chrome.windows.create({
      url: "https://b668f58d-31b7-4c69-9e5d-84c5d5aafc41-00-2sb4thwao8kay.kirk.replit.dev/",
      type: "popup",
      width: width,
      height: height,
      left: left,
      top: top
    });
  });
});